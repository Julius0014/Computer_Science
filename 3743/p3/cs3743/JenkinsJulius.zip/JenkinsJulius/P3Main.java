package cs3743;

public class P3Main 
{
    public static void main(String[] args) throws Exception 
    {
        P3Program pgm = new P3Program("ubh226", "730pw");
        pgm.runProgram();
    }
}
